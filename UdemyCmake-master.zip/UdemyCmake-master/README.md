# CMake, Testing and Tooling for C/C++

This is the code to my Udemy course:
*CMake, Testing and Tooling for C/C++* by Jan Schaffranek.

## Sale-Coupons

Link to my sale coupons: [Link](https://github.com/franneck94/YoutubeVideos/blob/master/EnglishCourses.md)

## CMake Readme

The CMake Readme is in Chapter 2 see [here](./2_CMake/README.md)
