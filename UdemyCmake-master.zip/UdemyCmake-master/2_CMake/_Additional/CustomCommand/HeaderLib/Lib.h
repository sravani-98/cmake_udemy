#include <iostream>

template <typename N>
void printer(N value)
{
    std::cout << value << "\n";
}
