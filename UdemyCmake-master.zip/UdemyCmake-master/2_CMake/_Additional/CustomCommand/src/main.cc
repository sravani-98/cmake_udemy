#include "Lib.h"

int main(int argc, char const *argv[])
{
    printer(1);
    printer(2);

    return 0;
}
