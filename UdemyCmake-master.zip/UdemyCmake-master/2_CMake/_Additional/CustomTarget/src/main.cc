#include "Lib.h"

int main(int argc, char const *argv[])
{
    printer(1);

    return 0;
}
