#include "lib.h"

int main()
{
    Function();

    return 0;
}
