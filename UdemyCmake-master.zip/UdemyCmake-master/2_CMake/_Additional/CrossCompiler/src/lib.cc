#include "lib.h"

#include <iostream>

void Function()
{
    std::cout << "Called\n";
}
