#pragma once

void print_hello_world();
